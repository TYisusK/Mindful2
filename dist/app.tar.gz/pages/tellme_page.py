import os
import json
import threading
import requests
import flet as ft

from theme import BG, INK, MUTED, rounded_card
from ui_helpers import shell_header

GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"


def TellMeView(page: ft.Page):
    sess_user = page.session.get("user") if page.session else None
    username = "amig@"
    if isinstance(sess_user, dict):
        username = (
            sess_user.get("username")
            or (sess_user.get("email") or "amig@").split("@")[0]
            or "amig@"
        )

    header = shell_header("Mindful+ chat", "Un espacio seguro para conversar")

    # Contenedor principal del chat
    chat = ft.ListView(
        expand=True,
        spacing=12,
        padding=12,
        auto_scroll=True,  # mantiene el scroll abajo mostrando mensajes nuevos
    )

    # Campo de texto y botón
    input_field = ft.TextField(
        hint_text="Escribe aquí…",
        expand=True,
        border_radius=20,
        content_padding=ft.padding.symmetric(horizontal=16, vertical=10),
        bgcolor="#f9f8ff",
    )
    send_btn = ft.IconButton(icon=ft.Icons.SEND_ROUNDED, tooltip="Enviar", icon_color="#5B4BDB")

    # ---------------------- FUNCIONES ------------------------

    def add_message(text, is_user=False):
        """Crea y agrega un mensaje visual (burbuja)."""
        max_width = min(400, page.width * 0.75 if page.width else 380)
        color_bg = "#5B4BDB" if is_user else "#EDE7FF"
        color_text = "white" if is_user else INK
        align = ft.MainAxisAlignment.END if is_user else ft.MainAxisAlignment.START

        bubble = ft.Container(
            content=ft.Text(text, color=color_text, selectable=True),
            padding=ft.padding.symmetric(horizontal=14, vertical=10),
            bgcolor=color_bg,
            border_radius=20,
            width=max_width,
        )

        row = ft.Row([bubble], alignment=align)
        chat.controls.append(row)
        page.update()

    # Mensaje animado "Mindful está escribiendo..."
    typing_ref = ft.Ref[ft.Row]()
    typing_row = ft.Row(
        ref=typing_ref,
        controls=[
            ft.Container(
                bgcolor="#F4F1FF",
                border_radius=20,
                padding=ft.padding.symmetric(horizontal=12, vertical=8),
                content=ft.Row(
                    [
                        ft.ProgressRing(width=14, height=14, color="#5B4BDB"),
                        ft.Text("Mindful+ está escribiendo...", size=12, color=MUTED),
                    ],
                    spacing=8,
                    alignment=ft.MainAxisAlignment.START,
                ),
            )
        ],
        alignment=ft.MainAxisAlignment.START,
    )

    # --------------------------------------

    def call_gemini(prompt: str):
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            return "⚠️ No se encontró la API key (.env)."

        headers = {"Content-Type": "application/json"}
        url = f"{GEMINI_URL}?key={api_key}"
        payload = {
            "contents": [
                {
                    "parts": [
                        {
                            "text": (
                                "Eres Mindful+, el asistente emocional de la app Mindful. "
                                "Habla con calidez, empatía y sin juicios. "
                                "Responde en español y ofrece consuelo breve y esperanzador.\n\n"
                                f"Usuario: {prompt}"
                            )
                        }
                    ]
                }
            ]
        }

        try:
            r = requests.post(url, headers=headers, data=json.dumps(payload), timeout=25)
            r.raise_for_status()
            j = r.json()
            return j["candidates"][0]["content"]["parts"][0]["text"]
        except Exception as e:
            return f"💜 Lo siento, hubo un error al procesar tu mensaje: {e}"

    # --------------------------------------

    def send_message(e=None):
        text = input_field.value.strip()
        if not text:
            return

        add_message(text, is_user=True)
        input_field.value = ""
        input_field.disabled = True
        send_btn.disabled = True
        chat.controls.append(typing_row)
        page.update()

        def task():
            reply = call_gemini(text)

            def finish():
                if typing_row in chat.controls:
                    chat.controls.remove(typing_row)
                add_message(reply, is_user=False)
                input_field.disabled = False
                send_btn.disabled = False
                page.update()
                input_field.focus()

            # Compatible con versiones antiguas de Flet:
            try:
                page.pubsub.send_all(finish)
            except Exception:
                finish()

        threading.Thread(target=task, daemon=True).start()

    send_btn.on_click = send_message
    input_field.on_submit = send_message

    # PubSub listener para actualizar desde hilos
    def on_msg(msg):
        if callable(msg):
            msg()

    page.pubsub.subscribe(on_msg)

    # Mensaje inicial
    intro = (
        f"Hola {username} 🌿 Soy Mindful+, tu acompañante emocional. "
        "Cuéntame cómo te sientes o qué pasó hoy. Estoy aquí para escucharte y apoyarte 💜."
    )
    add_message(intro, is_user=False)

    # --------------------------------------
    # ESTRUCTURA RESPONSIVE
    # --------------------------------------
    layout = ft.Column(
    [
        rounded_card(ft.Column([header], spacing=6), 16),
        ft.Container(chat, border_radius=16, bgcolor="white", expand=True),
        ft.Container(
            content=ft.Row(
                [input_field, send_btn],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            bgcolor="#F9F8FF",
            padding=10,
            border_radius=30,
            shadow=ft.BoxShadow(blur_radius=6, color=ft.Colors.with_opacity(0.15, ft.Colors.BLACK)),
        ),
    ],
    spacing=12,
    expand=True,
)


    return ft.View(route="/tellme", bgcolor=BG, controls=[layout])
