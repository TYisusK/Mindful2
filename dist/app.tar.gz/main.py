# main.py
import flet as ft
from pages.welcome_page import WelcomeView
from pages.register_page import RegisterView
from pages.login_page import LoginView
from pages.home_page import HomeView
from pages.notes_page import NotesView
from pages.note_editor_page import NoteEditorView
from pages.diagnostic_page import DiagnosticView
from pages.notes_page import NotesView
from pages.note_editor_page import NoteEditorView
from pages.recommendations_page import RecommendationsView
from pages.tellme_page import TellMeView




from dotenv import load_dotenv
load_dotenv()



def main(page: ft.Page):
    page.title = "Mindful"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.window_min_width = 360
    page.window_min_height = 640
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.scroll = ft.ScrollMode.ADAPTIVE
    page.vertical_alignment = ft.MainAxisAlignment.START

    def route_change(_):
        page.views.clear()

        # rutas principales
        if page.route == "/":
            # Pantalla de bienvenida con Iniciar sesión / Registrarse
            page.views.append(WelcomeView(page))
        elif page.route == "/register":
            page.views.append(RegisterView(page))
        elif page.route == "/login":
            page.views.append(LoginView(page))
        elif page.route == "/home":
            # Página principal con las tarjetas (dashboard)
            page.views.append(HomeView(page))
        
        elif page.route == "/diagnostic":
            # Página del test de diagnóstico
            page.views.append(DiagnosticView(page))
        elif page.route.startswith("/notes"):
            page.views.append(NotesView(page))
        elif page.route.startswith("/note_new"):
            page.views.append(NoteEditorView(page))  # sin id -> nueva
        elif page.route.startswith("/note_edit"):
            page.views.append(NoteEditorView(page))
        elif page.route.startswith("/recommendations"):
            page.views.append(RecommendationsView(page))
        elif page.route.startswith("/tellme"):
            page.views.append(TellMeView(page))

        # Manejo opcional de redirección de OAuth (si algún día lo reactivas)
        elif "id_token=" in page.route:
            for view in page.views:
                if hasattr(view, "handle_google_redirect"):
                    view.handle_google_redirect(page.route)
                    break
        else:
            # fallback
            page.views.append(WelcomeView(page))

        page.update()

    def view_pop(_):
        page.views.pop()
        page.go(page.views[-1].route)

    page.on_route_change = route_change
    page.on_view_pop = view_pop
    page.go(page.route or "/")

if __name__ == "__main__":
    import flet as ft
    ft.app(target=main, assets_dir="assets", view=ft.WEB_BROWSER)
